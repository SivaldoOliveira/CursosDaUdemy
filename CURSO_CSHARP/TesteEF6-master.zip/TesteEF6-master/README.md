# TesteEF6
Exemplo de CRUD com EF6
